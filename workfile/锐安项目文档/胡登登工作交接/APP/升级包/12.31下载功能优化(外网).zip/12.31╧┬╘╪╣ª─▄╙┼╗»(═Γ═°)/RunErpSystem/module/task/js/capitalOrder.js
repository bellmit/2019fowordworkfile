var appUserInfo = {};
var cgId;
var procInstId;
var fileIds=null;
//页面初始化-初始化微信用户信息
$(function() {
    if(localStorage.wxUser!=null){
		var data = JSON.parse(localStorage.wxUser);
		appUserInfo.mUserName=data.userName;
		userId = data.userId;
	}else{
		mui.toast('网络异常！');
	}
    var parameter = JSON.parse(localStorage.parameter);
	procInstId = parameter.procInstId;
	cgId = parameter.cgId;
	initView();
})(mui);
//初始化费用资金申请数据
function initView() {
	$.ajax({
		url:pathUrl+'/capitalView.action',
		type:"post",
		data:{
			procInstId:procInstId,
			id:cgId,
			userId:userId,
			isFrom:'cp'
		},
		async:false,/*同步请求*/
		dataType:'json',
		success:function(data){
			var json = JSON.parse(data);
			fyMaterialDetail(json.fyMaterialDetail);
			fySupplierDetail(json.fySupplierDetail);
			if(json.currProcessNode=="经办人 部门总监"){
				$("#files").css("display","block");
			}
			list(json);
			cgFy(json);
			$('input[type="text"]').attr('disabled','disabled');
		}
	});
}

//历史审批记录
function list(json){
	if(json.hasOwnProperty("list")){
		var data = JSON.parse(json.list);
		$.each(data.list,function(i,list){
			var attitude="";
			if(list.attitude=="1"){
				attitude="同意";
			}else{
				attitude="不同意";
			}
			var time=list.taskFinishTime.substring(0,10);
			var html='<li class="clearfix "><span class="left label">审批人：</span> '+
						'<input type="text" id="" class="f_input right wp60" value="'+list.taskUser+'">'+
					'</li>'+
					'<li class="clearfix "><span class="left label">审批结果：</span> '+
						'<input type="text" id="" class="f_input right wp60" value="'+attitude+'">'+
					'</li>'+
					'<li class="clearfix "><span class="left label">审批意见：</span> '+
						'<input type="text" id="" class="f_input right wp60" value="'+list.message+'">'+
					'</li>'+
					'<li class="clearfix "><span class="left label">审批时间：</span> '+
						'<input type="text" id="" class="f_input right wp60" value="'+time+'">'+
					'</li></br>';
			$("#apply").append(html);
		})
	}
}
//生成费用资金申请基本信息
function cgFy(json){
	id=json.cgFy.id;
	fileIds=json.cgFy;
	$("#id").val(json.cgFy.id);
	$("#askName").val(json.cgFy.askName);
	$("#askDeptName").val(json.cgFy.askDeptName);
	$("#askDate").val(json.cgFy.askDate);
	$("#sku").val(json.cgFy.sku);
	$("#companyCode").val(json.cgFy.companyCode);
	$("#needFpName").val(json.cgFy.needFpName);
	$("#cgGroupName").val(json.cgFy.cgGroupName);
	$("#needContractName").val(json.cgFy.needContractName);
	$("#title").val(json.cgFy.title);
	$("#wantDhDate").val(json.cgFy.wantDhDate);
	$("#isGzName").val(json.cgFy.isGzName);
	$("#needAgreementName").val(json.cgFy.needAgreementName);
	$("#agreementSku").val(json.cgFy.agreementSku);
	$("#isXmylName").val(json.cgFy.isXmylName);
	$("#negotiateTitle").val(json.cgFy.negotiateTitle);
	$("#sapSku").val(json.cgFy.sapSku);
	$("#isCdName").val(json.cgFy.isCdName);
	$("#isCdName").val(json.cgFy.isCdName);
	$("#cancelDate").val(json.cgFy.cancelDate);
	$("#fyyt").text(json.cgFy.fyyt);
	$("#zbspFileName").text(json.cgFy.zbspFileName);
	$("#htFileName").text(json.cgFy.htFileName);
	$("#bjdFileName").text(json.cgFy.bjdFileName);
	$("#zdcghFileName").text(json.cgFy.zdcghFileName);
	$("#otherFileName").text(json.cgFy.otherFileName);
	$("#commitment1Name").text(json.cgFy.commitment1Name);
	$("#commitment3Name").text(json.cgFy.commitment3Name);
	$("#commitment2Name").text(json.cgFy.commitment2Name);
	
}
//采购物品规格型号数量
function fyMaterialDetail(json){
	$.each(json,function(i,list){
		var projectName = '';
		var projectSku = '';
		var deptName = '';
		var centerTitle = '';
		if(list.projectName != undefined){
			projectName = list.projectName;
		}
		if(list.projectSku != undefined){
			projectSku = list.projectSku;
		}
		if(list.deptName != undefined){
			deptName = list.deptName;
		}
		if(list.centerTitle != undefined){
			centerTitle = list.centerTitle;
		}
		var html="<li class='clearfix '><span class='left label'>科目分配类别：</span> "+
			"<input type='text' id='typeName' class='f_input right wp60' value="+list.typeName+">"+
			"</li>"+
			"<li class='clearfix '><span class='left label'>项目预算名称：</span> "+
				"<input type='text' id='projectName' class='f_input right wp60' value="+projectName+">"+
			"</li>"+
			"<li class='clearfix '><span class='left label'>项目预算编号：</span> "+
				"<input type='text' id='projectSku' class='f_input right wp60' value="+projectSku+">"+
			"</li>"+
			"<li class='clearfix '><span class='left label'>一级部门：</span> "+
				"<input type='text' id='deptName' class='f_input right wp60' value="+deptName+">"+
			"</li>"+
			"<li class='clearfix '><span class='left label'>损益表承担部门：</span> "+
				"<input type='text' id='centerTitle' class='f_input right wp60' value="+centerTitle+">"+
			"</li>"+
			"<li class='clearfix '><span class='left label'>申请人：</span> "+
				"<input type='text' id='askName' class='f_input right wp60' value="+list.askName+">"+
			"</li>"+
			"<li class='clearfix '><span class='left label'>采购物品规格型号：</span> "+
				"<input type='text' id='spec' class='f_input right ' style='width:55%;' value="+list.spec+">"+
			"</li>"+
			"<li class='clearfix '><span class='left label'>数量：</span> "+
				"<input type='text' id='num' class='f_input right wp60' value="+list.num+">"+
			"</li>"+
			"<li class='clearfix '><span class='left label'>单价：</span> "+
				"<input type='text' id='price2' class='f_input right wp60' value="+list.price+">"+
			"</li>"+
			"<li class='clearfix '><span class='left label'>货币：</span> "+
				"<input type='text' id='currencyName2' class='f_input right wp60' value="+list.currencyName+">"+
			"</li>"+
			"<li class='clearfix '><span class='left label'>税率：</span> "+
				"<input type='text' id='taxRateName' class='f_input right wp60' value="+list.taxRateName+">"+
			"</li>"+
			"<li class='clearfix '><span class='left label'>费用类型：</span> "+
				"<input type='text' id='categoryTitle' class='f_input right wp60' value="+list.categoryTitle+">"+
			"</li>";
		$("#fyMaterialDetail").append(html);
	});
}
//生成供货商信息
function fySupplierDetail(json){
	$.each(json,function(i,list){
		var isCheck="";
		if(list.isCheck=="1"){
			isCheck="是";
		}
		var html="<li class='clearfix '><span class='left label'>供货商：</span>"+
				"<input type='text' id='supplierName' class='f_input right wp60' value="+list.supplierName+">"+
			"</li>"+
			"<li class='clearfix '><span class='left label'>供货商编号：</span> "+
				"<input type='text' id='supplierSku' class='f_input right wp60' value="+list.supplierSku+">"+
			"</li>"+
			"<li class='clearfix '><span class='left label'>总计：</span> "+
				"<input type='text' id='price' class='f_input right wp60' value="+list.price+">"+
			"</li>"+
			"<li class='clearfix '><span class='left label'>货币：</span> "+
				"<input type='text' id='currencyName' class='f_input right wp60' value="+list.currencyName+">"+
			"</li>"+
			"<li class='clearfix '><span class='left label'>备注：</span> "+
				"<span type='text' id='remark' class='f_input mui-pull-right' style='padding-right:10px'>"+list.remark+"</span>"+
			"</li>"+
			"<li class='clearfix '><span class='left label'>使用此家：</span> "+
				"<input type='text' id='isCheck' class='f_input right wp60' value="+isCheck+">"+
			"</li>";
		$("#fySupplierDetail").append(html);
	});
}
//返回操作
function returnCapital(){
	mui.back();
}

function fileDown(fileId){
	var id=0;
	var fileName=null;
	if(fileId=="zbspFile"){
	
		fileName=$("#zbspFileName").text();
		id=fileIds.zbspFile;
	}else if(fileId=="htFile"){
		
		fileName=$("#htFileName").text();
		id=fileIds.htFile;
	}else if(fileId=="bjdFile"){
	
		fileName=$("#htFileName").text();
		id=fileIds.bjdFile;
	}else if(fileId=="zdcghFile"){
	
		fileName=$("#htFileName").text();
		id=fileIds.zdcghFile;
	}else if(fileId=="otherFile"){
	
		fileName=$("#htFileName").text();
		id=fileIds.otherFile;
	}else if(fileId=="commitment1"){
	
		fileName=$("#htFileName").text();
		id=fileIds.commitment1;
	}else if(fileId=="commitment2"){
	
		fileName=$("#htFileName").text();
		id=fileIds.commitment2;
	}else if(fileId=="commitment3"){
		
		fileName=$("#htFileName").text();
		id=fileIds.commitment3;
	}
	window.open(pathUrl+"taskFile.action?id="+id+"&fileName="+fileName); 
}
