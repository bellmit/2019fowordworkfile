var delfile = [];
var fileName;
var files;
mui.ready(function() {
	//添加文件
	$('.fileAdd').off().on('click',function(){
	    var inputName = new Date().getTime();
	    var _html = '<input type="file" class="hide fileInput" data-id="'+inputName+'" multiple/>';
	    $('.fileBox').after(_html);
	
	    $('input[data-id="'+inputName+'"]').click();
	});

	//文件选择变化
	$('.fileInput').die().live('change',function(e) {
		var _html = '';
		var filelength = e.target.files.length;
		if((filelength+$('.fileBox .imgbtn').length)>1){
			mui.confirm('不能同时上传多个文件', '', ['确定'], function(e) {
			});
			return false;
		}
		if(e.target.files.length<=1){
			var file = e.target.files[0];
			var strFile = file.name;
	   		fileName = file.name;
	   		$("#fileName").text(fileName);
			if(strFile.indexOf(";")!=-1){
				mui.confirm('文件名称不能带 ; ', '', ['确定'], function(e) {
				});
				return false;
			}
			//上传控制！！！！！！！！
			const imgMaxSize = 1024 * 1024 * 5 ; // 5MB
			// 检查文件类型
	
			// 文件大小限制
			if(file.size > imgMaxSize ) {
				showAlert("文件大小不能超过5MB！");
				return false;
			}	
			if(file.name!=null&&file.name!='/'){
				goToFileUp(file);
				_html='<span class="imgbtn left relative" data-input="'+$(e.target).attr("data-id")+'" data-time="'+file.lastModified+'">'+
			         '<img src="../../images/imgicon.png" class="imgicon" />'+
			         '<a href="javascript:;" class="imgdelbtn">'+
			         '<img src="../../images/delicon.png" alt class="imgdelicon" />'+					
			         '</a>'+
			         '</span>';
			}
	
		}else{
			var x = 100;
			var y = 0;
	   		var rand = parseInt(Math.random() * (x - y + 1) + y);
			var file = e.target.files;
			$.each(file,function(i,item){
				var strFile=item.name;
				if(strFile.indexOf(";")!=-1){
					mui.confirm('文件名称不能带 ; ', '', ['确定'], function(e) {
					});
					return false;
				}
				//上传控制！！！！！！！！
				const imgMaxSize = 1024 * 1024 * 5; // 5MB
				// 检查文件类型
	
				// 文件大小限制
				if(file.size > imgMaxSize ) {
					showAlert("文件大小不能超过5MB！");
					return false;
				}	
				if(file.name!=null&&file.name!='/'){
					goToFileUp(file);
	                _html+='<span class="imgbtn left relative" data-input="'+$(e.target).attr("data-id")+'" data-time="'+item.lastModified+'">'+
	                    '<img src="../../images/imgicon.png" class="imgicon"/>'+
	                    '<a href="javascript:;" class="imgdelbtn">'+
	                    '<img src="../../images/delicon.png" alt class="imgdelicon" />'+
	                    '</a>'+
	                    '</span>';
				}
			});
		}
		$('.fileBox').append(_html);
	    
	});
	//关闭文件
	$('.imgdelbtn').die().live('touchend',function(){
		var fileId = $(this).parent().attr('data-time'); //file中的lastModified
		delfile.push(fileId);
		$(this).parent().remove();
		$("#fileName").text("");
		return false;
	});
});
function goToFileUp(file){
			
	// 图片上传							
	//transformFileToFormData(file);	
	// 图片压缩绘制
	// transformFileToDataUrl(file);
	// 图片上传
	transformFileToFormData(file);
}
// 将File append进 FormData
function transformFileToFormData (file) {
	localStorage.files=file.size;
    const formData = new FormData();
    // name
    formData.append('name', file.name);
    // append 文件
    formData.append('businessFile', file);	
    // 上传图片
    uploadMobileFile(formData);
}
function uploadMobileFile(formData){
	var sku=$("#sku").val();
	$.ajax({
		url: pathUrl+'/attFileMobile.action?sku='+sku+"&flag=xy",
		type:"post",
		data:formData,
		async:false,/*同步请求*/
		dataType:"json",
		contentType:false,
		processData:false,
		error : function(){
			$("#fileName").text("");
			mui.toast("上传图片失败！");
		},
		success:function(data){
			var data=JSON.parse(data);
			if(data.attachmentId!="" || data.attachmentId!=null){
				localStorage.dzfjFile=data.attachmentId;
				$("#fileName").text(fileName);
				mui.confirm(data.result, '', ['确定'], function(e) {
				});
			}else{
				$("#fileName").text("");
				mui.confirm('图片太大了！', '', ['确定'], function(e) {
				});
			}				
			
		}
	});
}
//协议文件下载
function fileDown(fileId){
	var id=0;
	var fileName=null;
	if(fileId=="xyFile"){
		fileName=$("#xyFile").text();
		id=fileIds.xyFile.id;
	}else if(fileId=="gysghnlFile"){
		fileName=$("#gysghnlFile").text();
		id=fileIds.gysghnlFile.id;
	}else if(fileId=="companyFile"){
		fileName=$("#companyFile").text();
		id=fileIds.companyFile.id;
	}else if(fileId=="personFile"){
		fileName=$("#personFile").text();
		id=fileIds.personFile.id;
	}else if(fileId=="zbFile"){
		fileName=$("#zbFile").text();
		id=fileIds.zbFile.id;
	}else if(fileId=="cpxxFile"){
		fileName=$("#cpxxFile").text();
		id=fileIds.cpxxFile.id;
	}else if(fileId=="cpdlsFile"){
		fileName=$("#cpdlsFile").text();
		id=fileIds.cpdlsFile.id;
	}else if(fileId=="otherFile"){
		fileName=$("#otherFile").text();
		id=fileIds.otherFile.id;
	}else if(fileId=="dzfjFile"){
		fileName=$("#dzfjFile").text();
		id=fileIds.dzfjFile.id;
	}else if(fileId=="cancelFile"){
		fileName=$("#cancelFile").text();
		id=fileIds.cancelFile.id;
	}
	window.open(pathUrl+"taskFile.action?id="+id+"&fileName="+fileName); 
}
//协议待办回显职责
function responsibility(type,ctype){
	if(type==90){
		$("#responsibility").text("所有节点审批完成后，须在5个工作日内，上传签字、盖章的电子附件并提交协议原件存档");
	}else{
		if(ctype==5){
			if(type==1){
				$("#responsibility").text("对协议的必要性进行严格审核,"
				+"对协议的真实性、合法性、合理性进行全面的、实质的审查，并承担主要审核责任。"
				+"保证本人未违反《渠道管理规定》和国家相关法律法规,"
				+"发起人部门总经理需与公司签订《廉洁承诺书》,"
				+"对协议内商品定价的合理性进行审查，核实；"
				+"审核所签署的《xx项目供货/服务协议》是否有对应的《廉洁承诺书》");
			}else if(type==2){
				$("#responsibility").text("产品预计授权的行业、区域是否与公司已发牌照冲突；审核所签署的《xxx产品/服务代理协议》是否有对应的《廉洁承诺书》");
			}else if(type==3){
				$("#responsibility").text("拟与代理商签订的《xxx产品/服务代理协议》等文件是否在公司发布的模板上进行了修改，是否符合法律要求；");
			}else if(type==4){
				$("#responsibility").text("对协议的必要性进行严格审核"
				+"对协议进行业务审查，并承担管理责任");
			}else if(type ==5){
				$("#responsibility").text("进对协议的必要性进行严格审核对协议进行业务审查，并承担管理责任");
			}else if(type ==6){
				$("#responsibility").text("进行形式审查，即申请是否已经完成了前置审查的全部流程，并承担管理责任。高管审核人可以自行或根据任一审核流程中的审核人的请求，对申请进行实质审查");
			}else if(type ==0){
				$("#responsibility").text("保证协议的必要性和真实性;保证协议所针对的采购业务和合作方法是唯一的;保证协议不触犯国家相关法律;协调合作商与公司签订《廉洁承诺书》;申请人需与公司签订《廉洁承诺书》");
			}else{
				$("#responsibility").text("");
			}
		}else if(ctype==6){
			if(type==1){
				$("#responsibility").text("保证协议的必要性和真实性保证协议不违反《渠道管理规定》;保证协议所针对的项目和合作方法是唯一的;保证协议不触犯国家相关法律;协调合作商与公司签订《廉洁承诺书》;申请人需与公司签订《廉洁承诺书》");
			}else if(type==2){
				$("#responsibility").text("拟与合作商签订的协议等文件是否在公司发布的模板上进行了修改，是否符合法律要求；");
			}else if(type==3){
				$("#responsibility").text("对协议的必要性进行严格审核对协议进行业务审查，并承担管理责任");
			}else if(type==4){
				$("#responsibility").text("进行形式审查，即申请是否已经完成了前置审查的全部流程，并承担管理责任。高管审核人可以自行或根据任一审核流程中的审核人的请求，对申请进行实质审查");
			}else if(type ==5){
				$("#responsibility").text("进行形式审查，即申请是否已经完成了前置审查的全部流程，并承担管理责任。高管审核人可以自行或根据任一审核流程中的审核人的请求，对申请进行实质审查");
			}else if(type ==0){
				$("#responsibility").text("保证协议的必要性和真实性;保证协议所针对的采购业务和合作方法是唯一的;保证协议不触犯国家相关法律;协调合作商与公司签订《廉洁承诺书》;申请人需与公司签订《廉洁承诺书》");
			}else{
				$("#responsibility").text("");
			}
		}else if(ctype==2){
			if(type==1){
				$("#responsibility").text("对协议的必要性进行严格审核对协议的真实性、合法性、合理性进行全面的、实质的审查，并承担主要审核责任。保证本人未违反国家相关法律法规发起人部门总经理需与公司签订《廉洁承诺书》;审核所签署的《协议》是否有对应的《廉洁承诺书》");
			}else if(type==2){
				$("#responsibility").text("拟与合作商签订的协议等文件是否在公司发布的模板上进行了修改，是否符合法律要求；");
			}else if(type==3){
				$("#responsibility").text("对协议的必要性进行严格审核对协议进行业务审查，并承担管理责任");
			}else if(type ==4){
				$("#responsibility").text("进行形式审查，即申请是否已经完成了前置审查的全部流程，并承担管理责任。高管审核人可以自行或根据任一审核流程中的审核人的请求，对申请进行实质审查");
			}else if(type ==5){
				$("#responsibility").text("进行形式审查，即申请是否已经完成了前置审查的全部流程，并承担管理责任。高管审核人可以自行或根据任一审核流程中的审核人的请求，对申请进行实质审查");
			}else if(type ==0){
				$("#responsibility").text("保证协议的必要性和真实性;保证协议所针对的采购业务和合作方法是唯一的;保证协议不触犯国家相关法律;协调合作商与公司签订《廉洁承诺书》;申请人需与公司签订《廉洁承诺书》");
			}else{
				$("#responsibility").text("");
			}
		}else{
			if(type==1){
				$("#responsibility").text("对协议的必要性进行严格审核"
				+"对协议的真实性、合法性、合理性进行全面的、实质的审查，并承担主要审核责任。"
				+"保证本人未违反《渠道管理规定》和国家相关法律法规"
				+"发起人部门总经理需与公司签订《廉洁承诺书》"
				+"对协议内商品定价的合理性进行审查，核实；"
				+"审核所签署的《xx项目供货/服务协议》是否有对应的《廉洁承诺书》");
			}else if(type==2){
				$("#responsibility").text("对协议的必要性进行严格审核"
				+"对协议进行业务审查，并承担管理责任");
			}else if(type==3){
				$("#responsibility").text("拟与合作商签订的《xx项目供货/服务协议》等文件是否在公司发布的模板上进行了修改，是否符合法律要求；");
			}else if(type==4){
				$("#responsibility").text("对协议的必要性进行严格审核"
				+"对协议进行业务审查，并承担管理责任");
			}else if(type ==5){
				$("#responsibility").text("进行形式审查，即申请是否已经完成了前置审查的全部流程，并承担管理责任。高管审核人可以自行或根据任一审核流程中的审核人的请求，对申请进行实质审查");
			}else if(type ==6){
				$("#responsibility").text("进行形式审查，即申请是否已经完成了前置审查的全部流程，并承担管理责任。高管审核人可以自行或根据任一审核流程中的审核人的请求，对申请进行实质审查");
			}else{
				$("#responsibility").text("");
			}
		}	
	}
}