var procInsId;
var taskId;
var taskUser;
var id;
var appUserInfo = {};

//页面初始化-初始化微信用户信息
(function($) {
    $.init();
    if(localStorage.wxUser!=null){
		var data = JSON.parse(localStorage.wxUser);
		appUserInfo.mUserName=data.userName;
		appUserInfo.mUserId = data.userId;
	}else{
		mui.toast('网络异常！');
	}
    var data = JSON.parse(localStorage.obj);
	procInstId = data.procInstId;
	taskId = data.taskId;
	taskUser = data.taskUser;
	initView();
})(mui);
//生成日报审批的详细数据
function initView() {
	$.ajax({
		url:pathUrl+'/dailyCost.action',
		type:"post",
		data:{
			procInstId:procInstId,
			taskId:taskId,
			taskUser:taskUser,
			userName:appUserInfo.mUserName
		},
		async:false,/*同步请求*/
		dataType:'json',
		success:function(data){
			var jsonData = JSON.parse(data);
			//日报基本信息
			if (jsonData.dailyInfo) {
			    dailyId = jsonData.dailyInfo.id;
			}
			$('#dailyDate').html(jsonData.dailyInfo.dailyDateStr+"日报");
			$('#applyUser').html(jsonData.dailyInfo.applyUser);
			$('#submitDate').html(jsonData.dailyInfo.submitDateStr+"提交");
			$('#site').html(jsonData.dailyInfo.site);
			$('#evaluate').html(jsonData.dailyInfo.evaluate);
			$('#evaluateDisc').html(jsonData.dailyInfo.evaluateDisc);
			$('#checkDesc').val(jsonData.dailyInfo.checkDesc);
			$('#showNo').html(jsonData.dailyInfo.evaluate);
			$('#checkDate').html(jsonData.dailyInfo.checkDate);
			//报工内容
			initDailyWork(jsonData.workList);
			//报销
			initDailySpend(jsonData.dailySpend);
			//发票
			initDailyAssort(jsonData.dailyAssort);
			daka(jsonData.attendInfo);
			$.each(jsonData.logList,function(i,flow){
				if(flow.isAgree==1){
					flow.isAgree="同意";
				}else{
					flow.isAgree="不同意";
				}
	    	    var html="<div class='mui-card-content-inner'>"+
			                 "<span class='mui-pull-left'>审批人</span>"+
			                 "<span class=' mui-pull-right'>"+flow.taskUser+"</span>"+
			             "</div>"+
			             "<div class='mui-card-content-inner'>"+
			                 "<span class='mui-pull-left'>审批结果</span>"+
			                 "<span class=' mui-pull-right'>"+flow.isAgree+"</span>"+
			             "</div>"+
			             "<div class='mui-card-content-inner'>"+
				             "<span class='mui-pull-left'>审批时间</span>"+
				             "<span class=' mui-pull-right'>"+formatDate(flow.taskFinishTime)+"</span>"+
			             "</div>"+
			             "<div class='mui-card-content-inner'>"+
				             "<span>审批意见</span>"+
				             "<span class=' mui-pull-right'>"+flow.examineOption+"</span>"+
			             "</div>"
			     $("#auditHis").append(html);
		     });
		}
	});
	$("#spr").text(appUserInfo.mUserName);
}
//生成报工内容
function initDailyWork(workList){
	$.each(workList,function(i,work){
		if(!work.workHour){
			work.workHour=0;
		}
		var url ='';
			var fileName='';
			if(work.fileDownLoadUrl){
				url=work.fileDownLoadUrl.substring(29);
				fileName = work.fileName;
		}
		html="<li class=' mui-media relative mui-table-view-cell'>"+
						"<div class='myui-circle-list-icon mui-pull-left'><span id='workHourSon'>"+work.workHour+" <em>h</em></span></div>"+
						"<div class='mui-media-body mui-pull-left'>"+
							"用时<span class='l10 blue' id='time'>"+work.startTime+"-"+work.endTime+"</span>"+
							"<p class='mui-ellipsis clearfix' id='jobPath'>成果路径："+work.jobPath+"</p>"+
						"</div>"+
						"<div class='clear'></div>"+
						"<div class='line'></div>"+
						"<span class=' left' id='proNo'>项目预算编号："+work.proNo+"</span></br>"+
						"<span class=' left' id='proNo'>任务完成进度："+work.jobRate+"%</span></br>"+
						"<span class=' left' id='proMile'>里程碑："+work.proMile+"</span></br>"+
						"<span class=' left' id='jobName'>任务名称："+work.jobName+"</span></br>"+
						"<span  id='jobDisc'>任务描述："+work.jobDisc+"</span></br>"+	
						"<span>交付物：<a onclick='down("+url+","+i+")' id='fileName_"+i+"'>"+fileName+"</a></span>"+	
					"</li>";
		$("#work").append(html);
	});
}
//生成报销信息
function initDailySpend(dailySpend){
	var attachmentName='';

	$.each(dailySpend,function(i,spend){
		if(spend.attachmentName){
				attachmentName = spend.attachmentName;
		}
		var spendDate="";
		if(spend.spendDate){
			spendDate=formatDate2(spend.spendDate);
		}
		html="<div >"+
				"<li class='mui-table-view-cell'>"+
					"<span class='left ' id='proNoS'>项目编号："+spend.proNo+"</span></br>"+
					"<span class='left ' id='proNoS'>预算编号："+spend.trueProject+"</span></br>"+
					"<span class='left ' id='allotUser'>报销单号："+spend.spendNo+"单</span></br>"+
					"<span class='left '>花消分类："+spend.budgetType+"</span></br>"+
					"<span class='left ' id='spendType'>消费类型："+spend.spendType+"</span></br>"+
					"<span class='left ' id='spendDate'>划卡日期："+spendDate+"</span></br>"+
					"<span class='left ' id=''>花销统计：</span></br>"+
					"<span>附件：<a onclick='downAttachment("+spend.attachmentId+","+i+")' id='attachmentName_"+i+"'>"+attachmentName+"</a></span>"+	
				"</li>"+
			"</div>";
		$("#spend").append(html);
	});
}
//生成发票信息
function initDailyAssort(dailyAssort){
	var yuan="";
	if(assort.rideType){
		yuan=assort.rideType;
	}
	if(assort.rideTime){
		yuan=formatDate(assort.rideTime);
	}
	$.each(dailyAssort,function(i,assort){
		html="<li class='mui-table-view-cell'>"+
				"<div>"+
					"<div class='left' id='ticketType'>报销单号："+assort.spendNo+"单</div></br>"+
					"<div class='left' id='ticketType'>发票类型："+assort.ticketType+"</div></br>"+
					"<span class=left' id='spendMoney'>花销金额："+assort.spendMoney+"</span></br>"+
					"<div class='left '>报销单号（后4位）："+assort.code+"</div></br><span id='code_"+i+"'></span>"+
					"<div class='left' id='rate'>税率&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;："+assort.rate+"</div></br>"+
					"<div class='left' id='ticketCom'>开票单位："+assort.ticketCom+"</div></br>"+
					"<div class='left' id='ticketInfo'>发票内容："+assort.ticketInfo+"</div></br>"+
					"<div class='left' id='remark'>备注&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;："+assort.remark+"</div></br>"+	
					"<div class='left' id='remark'>住宿地点："+(assort.shrikPlace==null?"":assort.shrikPlace)+"</div></br>"+	
					"<div class='left' id='remark'>入住日期："+(assort.checkInDate==null?"":assort.checkInDate)+"</div></br>"+	
					"<div class='left' id='remark'>离店日期："+(assort.leaveDate==null?"":assort.leaveDate)+"</div></br>"+	
					"<div class='left' id='rideType'>乘车原因/时间："+yuan+"</div></br>"+
					"<div class='left' id='teamSite'>团建时间/地点："+assort.teamSite+"</div></br>"+
					"<div class='left' id='teamUser'>团建人员："+assort.teamUser+"</div></br>"+
				"</div>"+
			"</li>";
		$("#assort").append(html);
		if(assort.ddOrderNum){
			$("#code_"+i).after("<div class='left '>订单号："+assort.ddOrderNum+"</div></br>");
		}
	});
}
//审批提交
function checkDaily(){
	var ifAgree=$("#ifAgree").find(".mui-btn-primary").html();
	var comment=$("#dailyCheck").val();
	var btnArray = ['确定'];
	$.ajax({
		url: pathUrl +'/CheckDailySpend.action',
		type:'post',
		data:{
			procInstId:procInstId,
			ifAgree:ifAgree,
			taskId:taskId,
			taskUser:taskUser,
			comment:comment
		},
		async:false,/*同步请求*/
		dataType:'jsonp',
		jsonp:'callback',
		jsonpCallback:'flightHandler',
		success:function(data){
		    var jsonData = JSON.parse(data);
			if(jsonData.result && 'success' == jsonData.result){
				mui.confirm('审批成功！', '提示', btnArray, function(e) {
					mui.openWindow({
						url:"agencyList.html"
					});
				});	
			}else{
				mui.confirm(jsonData.message, '提示', btnArray, function(e) {
					mui.openWindow({
						url:"agencyList.html"
					});
				});
			}
		}
	});
}
function daka(list){
	var html='<div class="mui-media detailMsg fadeBox">'+
		'<span class="mui-col-xs-6 ">上午上班&nbsp;'+ list.amAttendStr + '</span>' +
		'<span class="mui-col-xs-6 right">状态&nbsp;：'+ (list.describe1==null?"":list.describe1) + '</span></br>' +
		'<span class="mui-col-xs-6 ">地点&nbsp;：'+ (list.site1==null?"":list.site1)+ '</span></br>' +
		'<span class="mui-col-xs-6 ">上午下班&nbsp;'+ list.amClosingStr + '</span>' +
		'<span class="mui-col-xs-6 right">状态&nbsp;：'+ (list.describe2==null?"":list.describe2)+ '</span></br>' +
		'<span class="mui-col-xs-6 ">地点&nbsp;：'+ (list.site2==null?"":list.site2) + '</span></br>' +
		'<span class="mui-col-xs-6 ">下午上班&nbsp;'+ list.pmAttendStr + '</span>' +
		'<span class="mui-col-xs-6 right">状态&nbsp;：'+ (list.describe3==null?"":list.describe3) + '</span></br>' +
		'<span class="mui-col-xs-6 ">地点&nbsp;：'+ (list.site3==null?"":list.site3) + '</span></br>' +
		'<span class="mui-col-xs-6 ">下午下班&nbsp;'+ list.pmClosingStr + '</span>' +
		'<span class="mui-col-xs-6 right">状态&nbsp;：'+ (list.describe4==null?"":list.describe4) + '</span></br>' +
		'<span class="mui-col-xs-6 ">地点&nbsp;：'+ (list.site4==null?"":list.site4) + '</span></br>' +
		'</div>';
	$(".dakas").append(html);
}
function formatDate(now) { 
	 var data=new Date(now); 
     var year=data.getFullYear(); 
     var month=data.getMonth()+1; 
     var date=data.getDate(); 
     var hour=data.getHours(); 
     var minute=data.getMinutes(); 
     var second=data.getSeconds(); 
     return year+"."+month+"."+date+" "+hour+":"+minute+":"+second; 
} 

function formatDate2(now) { 
	 var data=new Date(now); 
     var year=data.getFullYear(); 
     var month=data.getMonth()+1; 
     var date=data.getDate();
     return year+"-"+month+"-"+date ;
} 
//文件下载
function down(id,i){
	var fileName=$("#fileName_"+i).text();
	window.open(pathUrl+"/taskFile.action?id="+id+"&fileName="+fileName+"&flag=1"); 
}
//费用报销文件下载
function downAttachment(id,i){
	var attachmentName=$("#attachmentName_"+i).text();
	window.open(pathUrl+"/taskFile.action?id="+id+"&fileName="+attachmentName+"&flag=1"); 
}