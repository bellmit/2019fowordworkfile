var userId="";
var types="";
var leaveType = "";
var applyTime = "";
var state = "";
var userName="";
//mui初始化
mui.init({
	swipeBack: true //启用右滑关闭功能
});
//初始化微信数据
 //var pathUrl="http://111.204.211.206:13011/RunErpSystem/";
var pathUrl="http://127.0.0.1:13011/RunErpSystem/";
(function($,doc) {
   setTimeout(function () {
       if(localStorage.wxUser!=null){
	       var data = JSON.parse(localStorage.wxUser);
	       userName=data.userName;
		   userId=data.userId;
		   getDataInfo();
		   //$("#applyUser").val(userName);
	   } else{
	       mui.toast('网络异常！');
	    }	
	}, 800);	
		
	var btns=$("#time");
	    btns.each(function(i, btn) {
	        btn.addEventListener('tap', function() {
		        var _self = this;
	    	    var optionsJson = '{"type":"month","beginYear":2010,"endYear":2030}';
	    	    var options = JSON.parse(optionsJson);
	    	    var id = this.getAttribute('id');
	    	    _self.picker = new $.DtPicker(options);
	    	    _self.picker.show(function(rs) {
	    		    btn.innerText = rs.text;
	    		    applyTime =rs.text;
	    		    _self.picker.dispose();
	    		    _self.picker = null;
					getDataInfo();
	    	    });
	        }, false);
	    });
	$.ready(function() {
		var _getParam = function(obj, param) {
			return obj[param] || '';
		};
		//类型
		var showStyle = new $.PopPicker();
		showStyle.setData([
		{
			value: '',
			text: '全部'
		},{
			value: '1',
			text: '年假'
		}, 
		{
			value: '2',
			text: '产检假'
		}, {
			value: '3',
			text: '离职职务假'
		},{
			value: '4', 
			text: '病假'
		},{
			value: '5', 
			text: '带薪病假'
		},{
			value: '6', 
			text: '陪护假'
		},{
			value: '7', 
			text: '计划生育假'
		},{
			value: '8', 
			text: '产假'
		},{
			value: '9', 
			text: '哺乳假'
		},{
			value: '10', 
			text: '调休假'
		},{
			value: '11', 
			text: '婚假'
		},{
			value: '12', 
			text: '事假'
		},{
			value: '13', 
			text: '丧假'
		},{
			value: '14', 
			text: '长期病假'
		}
		]);
		var showStyleButton = doc.getElementById('showStyle');
		var styleResult = doc.getElementById('showStyle');
		showStyleButton.addEventListener('tap', function(event) {
			showStyle.show(function(items) {
				styleResult.innerText = items[0].text;
				//返回 false 可以阻止选择框的关闭
				//return false;
				leaveType =items[0].value;
				getDataInfo();
			});
		}, false);
		//状态
		var showStat = new $.PopPicker();
		showStat.setData([{
			value: '0',
			text: '草稿'
		}, {
			value: '1',
			text: '驳回'
		}, {
			value: '2',
			text: '审批中'
		},{
			value: '3', 
			text: '审批通过'
		}]);
		var showStatButton = doc.getElementById('showStat');
		var statResult = doc.getElementById('showStat');
		showStatButton.addEventListener('tap', function(event) {
			showStat.show(function(items) {
				statResult.innerText = items[0].text;
				//返回 false 可以阻止选择框的关闭
				//return false;
				state =items[0].value;
				getDataInfo();
			});
		}, false);
	});

})(mui, document);
// 加载更多
/**mui.init({
		pullRefresh: {
			container: '#pullrefresh',
			down: {
				callback: pulldownRefresh
			},
			up: {
				contentrefresh: '正在加载...',
				callback: pullupRefresh
			}
		}
	});
	/**
	 * 下拉刷新具体业务实现function pulldownRefresh() {
		getDataInfo();
		mui('#pullrefresh').pullRefresh().endPulldownToRefresh(); //refresh completed
	}
	 */
	
	var currentPage=1;
	var pageCount=0;
	/**
	 * 上拉加载具体业务实现
	 */
	function pullupRefresh() {
		setTimeout(function() {
			//mui('#pullrefresh').pullRefresh().endPullupToRefresh((currentPage >= pageCount)); //参数为true代表没有更多数据了。
			var table = document.body.querySelector('#mui-table-view-list');
			var cells = document.body.querySelectorAll('.mui-table-view-cell');
			
			var leaveType = $("#showStyle").html().trim();
			var applyTime = $("#showTime").html().trim();
			var state = $("#showStat").html().trim();
			if(leaveType=='类型'){
				leaveType='';
			}
			if(applyTime=='时间'){
				applyTime='';
			}
			if(state=='状态'){
				state='';
			}
			$.ajax({
	//			url: 'http://192.168.0.93:8180/YJT_PMS/attend/appLeave/appList',
				url: pathUrl+'/appLeave.action',
				type:"post",
				data:{leaveType:leaveType,pageSize:31,currentPage:currentPage,applyTime:applyTime,state:state},
				async:false,/*同步请求*/
				dataType:'jsonp',
				jsonp:'callback',
				jsonpCallback:'flightHandler',
				success:function(data){
					
				    $.each(data.result,function(i,flow){
			    	var li = document.createElement('li');
						li.className = "mui-table-view-cell mui-media";
						li.innerHTML = "<div class='mui-slider-right mui-disabled'>"+
							"<a class='mui-btn mui-btn-red del' value='"+daily.id +"'>删除</a>"+
						"</div>"+
						"<a href='javascript:#;'  class='addApplyB' id='"+flow.flowId+"' name='"+flow.state+"' value='"+flow.id+"'>"+
							"<div>"+
								"<div class='myui-baobei-list-icon mui-pull-left'><span>"+flow.leaveType+"</span></div>"+
								"<div class='mui-media-body mui-pull-left'>"
									+flow.name+
									"<p class='mui-ellipsis clearfix blue'>"+flow.dept+"</p>"+
								"</div>"+
								"<span class='mui-badge mui-badge-success right'>"+flow.state+"</span>"+
							"</div>"+
							"<div class='clear'></div>"+
							"<div class='mui-media detailMsg fadeBox'>"+
								"<div>请假时间："+flow.startTime+" - "+flow.endTime+"</div>"+
								"<div>请假小时数： "+flow.leaveHours+"</div>"+
								"<div>申请日期："+flow.applyDate+"</div>"+
								"<div>审批人："+flow.current+"  </div>"+
							"</div>"+
						"</a>"
				
				$("#mui-table-view-list").append(li);
				
				});
				currentPage++;
				}
			});
		}, 1500);
	}
	//新增请假
function AddLeave(){
	var obj = {type:"add"};
	var leavelStr = JSON.stringify(obj);
	localStorage.leavelStr = leavelStr;
	mui.openWindow({
		url:"apply.html",
	});
}
//初始化页面数据
function getDataInfo(){
	currentPage=1;
	if(leaveType=='类型'){
		leaveType='';
	}
	if(applyTime=='时间'){
		applyTime='';
	}
	if(state=='状态'){
		state='';
	}
	var name=$("#applyUser").val();
	$.ajax({
		url: pathUrl+'/appLeave.action',
		type:"post",
		data:{leaveType:leaveType,pageSize:31,currentPage:1,applyTime:applyTime,state:state,userId:userId,applyName:name},
		async:false,/*同步请求*/
		dataType:'json',
		success:function(data){
			var json =JSON.parse(data);
			var html="";
			var html2="";
			$("#mui-table-view-list").html('');
			//0草稿、1驳回、2审批中、3审批通过、4撤销中、5撤销不通过、6撤销通过
		    $.each(json.data,function(i,flow){
		    	var state="";
		    	if(flow.state == "0"){
		    		state="草稿";
		    		html="<a class='mui-btn mui-btn-red ' value='' onclick='deletes("+flow.id+")'>删除</a>";
		    	}
		    	if(flow.state == "2"){
		    		state="审批中";
		    		html="<a class='mui-btn mui-btn-yellow ' value='' onclick='chex("+flow.id+")'>撤销</a>"
		    	}
		    	if(flow.state == "3"){
		    		state="审批通过";
		    		html="<a class='mui-btn mui-btn-yellow ' value='' onclick='chexs("+flow.id+")'>撤销</a>"
		    	}
		    	if(flow.state == "1" ){
		    		state="驳回";
		    		html="<a class='mui-btn mui-btn-red ' value='' onclick='deletes("+flow.id+")'>删除</a>";
		    	}
		    	if(flow.state =="4" ){
		    		state="审批中";
		    		html="<a class='mui-btn mui-btn-yellow ' value='' onclick='viewChex("+flow.id+")'>查看撤销</a>"
		    	}
		    	if(flow.state =="5" ){
		    		state="驳回";
		    		html="<a class='mui-btn mui-btn-red ' value='' onclick='viewChex("+flow.id+")'>删除撤销</a>"
		    	}
		    	if(flow.state == "6"){
		    		state="审批通过";
		    		html="<a class='mui-btn mui-btn-yellow ' value='' onclick='viewChex("+flow.id+")'>查看撤销</a>"
		    	}
		    	if(flow.state == "0" || flow.state== "1" || flow.state == "5"){
		    		html2="<a href='javascript:#;' onclick='edit("+flow.id+")'  class='addApplyB' id='"+flow.flowId+"' name='"+flow.state+"' value='"+flow.id+"'>";
		    	}else{
		    		html2="<a href='javascript:#;' onclick='lsevaView("+flow.id+","+flow.flowId+")'  class='addApplyB' id='"+flow.flowId+"' name='"+flow.state+"' value='"+flow.id+"'>";
		    	}
		    	if(!flow.currentAdjust){
		    		flow.currentAdjust="";
		    	}
		    	types=flow.state;
		    	var li = document.createElement('li');
					li.className = 'mui-table-view-cell mui-media';
					li.innerHTML = "<div class='mui-slider-right mui-disabled'>"+
							html+
						"</div>"+
						"<div class='mui-slider-handle'>"+
						"<div class='myui-list-title mui-pull-left '><span>"+flow.leaveType+"</span></div>"+
						html2+
						"<div>"+
							"<div class='mui-media-body mui-pull-left'>"
								+flow.name+
								"<div>申请日期："+flow.applyDate+"</div>"+
							"</div>"+
							"<span class='mui-badge mui-badge-success right'>"+state+"</span>"+
						"</div>"+
						"<div class='clear'></div>"+
						"<div class='mui-media detailMsg fadeBox'>"+
							"<div>请假时间："+flow.startTime+" - "+flow.endTime+"</div>"+
							"<div>请假小时数： "+flow.leaveHours+"</div>"+
							"<div>审批人："+flow.currentAdjust+"  </div>"+
						"</div>"+
						"</a>"+
						"</div>";
			$("#mui-table-view-list").append(li);
		    });
		    
		      //总页数
		    pageCount=data.pageCount;
		    currentPage=2;
		   // mui('#pullrefresh').pullRefresh().endPullupToRefresh((currentPage > pageCount));

		}
	});
}
function chex(id){
	$.ajax({
		url: pathUrl+'/revokeLeave.action',
		type:"post",
		data:{
			id:id,
			userId:userId
		},
		async:false,/*同步请求*/
		dataType:'json',
		success:function(data){
			var json=JSON.parse(data);
			if(json.msg=="sucess"){
				mui.confirm("撤销成功！", '提示', ['确定'], function(e) {
					mui.openWindow({
						url:"vacation-list.html",
					});
				});	
			}
		}
	});
}
//修改请假
function edit(leavelId){
	var obj = {leavelId:leavelId,type:"edit"};
	var leavelStr = JSON.stringify(obj);
	localStorage.leavelStr = leavelStr;
	mui.openWindow({
		url:"apply.html",
	});
}
//请假详情展示
function lsevaView(leavelId,flowId){
	var obj = {leavelId:leavelId,flowId:flowId};
	var leavelStr = JSON.stringify(obj);
	localStorage.leavelStr = leavelStr;
	mui.openWindow({
		url:"apply-detail.html",
	});
}
//删除请假
function deletes(id){
	$.ajax({
		url: pathUrl+'/deleteLeave.action', 
		type:"post",
		data:{
			id:id,
			userId:userId
		},
		async:false,/*同步请求*/
		dataType:'json',
		success:function(data){
			var json=JSON.parse(data);
			if(json.flag == true){
				mui.confirm('删除成功！', '提示', ['确定'], function(e) {
					mui.openWindow({
						url:"vacation-list.html",
					});
				});	
			}
		}
	});
}
//查看撤销详情
function viewChex(id){
	var obj = {leavelId:id,type:"backView"};
	var leavelStr = JSON.stringify(obj);
	localStorage.leavelStr = leavelStr;
	mui.openWindow({
		url:"apply-detail.html",
	});
}
//审批完成撤销
function chexs(id){
	var obj = {leavelId:id,type:"back"};
	var leavelStr = JSON.stringify(obj);
	localStorage.leavelStr = leavelStr;
	mui.openWindow({
		url:"apply-detail.html",
	});
}
$("#btn").on("click",function(){
	getDataInfo();
})
