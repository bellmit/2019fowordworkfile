var dailyId;
var procInsId;
var taskId;
var taskUser;
var appUserInfo = {};

//页面初始化-初始化微信用户信息及日报的评价信息
(function($, doc) {	
	$.init({
		swipeBack: true
	});
	if(localStorage.wxUser!=null){
		var data = JSON.parse(localStorage.wxUser);
		appUserInfo.mUserName=data.userName;
		appUserInfo.mUserId = data.userId;
		initUser(appUserInfo.mUserName);
	}else{
		mui.toast('网络异常！');
	}
	var data = JSON.parse(localStorage.obj);
	procInsId = data.procInstId;
	taskId = data.taskId;
	taskUser = data.taskUser;
	initDaily(procInsId, taskId, taskUser);
	var showStyle = new $.PopPicker();
		showStyle.setData([{
			value: 'A',
			text: 'A'
		},{
			value: 'B',
			text: 'B'
		}, {
			value: 'C',
			text: 'C'
		},{
			value: 'S', 
			text: 'S'
		}]);
		var showStyleButton = doc.getElementById('showNo');
		var styleResult = doc.getElementById('showNo');
		showStyleButton.addEventListener('tap', function(event) {
			showStyle.show(function(items) {
				styleResult.innerText = items[0].text;
				//返回 false 可以阻止选择框的关闭
				//return false;
			});
		}, false);
})(mui, document);
//生成日报的详细信息
function initDaily(procInsId, taskId, taskUser){
	setTimeout(function() {
		$.ajax({
			url: pathUrl +'/viewDailyAudit.action',
			type:'post',
	        data:{
	            procInstId:procInsId,
		        taskUser:taskUser,
		        taskId:taskId
	        },
			async:false,/*同步请求*/
			dataType:'jsonp',
			jsonp:'callback',
			jsonpCallback:'flightHandler',
			success:function(data){
			    var jsonData = JSON.parse(data);
				//日报基本信息
				if (jsonData.dailyInfo) {
				    dailyId = jsonData.dailyInfo.id;
				}
				$('#dailyDate').html(jsonData.dailyInfo.dailyDateStr+"日报");
				$('#applyUser').html(jsonData.dailyInfo.applyUser);
				$('#workHour').html(jsonData.dailyInfo.workHour);
				$('#subState').html(jsonData.dailyInfo.subState);
				$('#submitDate').html(jsonData.dailyInfo.submitDateStr+"提交");
				$('#site').html(jsonData.dailyInfo.site);
				$('#evaluate').html(jsonData.dailyInfo.evaluate);
				$('#evaluateDisc').html(jsonData.dailyInfo.evaluateDisc);
				$('#checkDesc').val(jsonData.dailyInfo.checkDesc);
				$('#showNo').html(jsonData.dailyInfo.evaluate);
				$('#checkDate').html(jsonData.dailyInfo.checkDate);
				//报工内容
				initDailyWork(jsonData.workList);
				//报销
				initDailySpend(jsonData.dailySpend);
				//发票
				initDailyAssort(jsonData.dailyAssort);
				//明日计划
				if(jsonData.dailyPlanList!=null){
					initDailyPlan(jsonData.dailyPlanList);
				}
				daka(jsonData.attendInfo);
			}
		});
		
	}, 1000);
}
//生成报工内容
function initDailyWork(workList){
	$.each(workList,function(i,work){
		if(!work.workHour){
			work.workHour=0;
		}
		var url ='';
		var fileName='';
		if(work.fileDownLoadUrl){
			url=work.fileDownLoadUrl.substring(29);
			fileName = work.fileName;
		}
		html="<li class=' mui-media relative mui-table-view-cell'>"+
						"<div class='myui-circle-list-icon mui-pull-left'><span id='workHourSon'>"+work.workHour+" <em>h</em></span></div>"+
						"<div class='mui-media-body mui-pull-left'>"+
							"用时<span class='l10 blue' id='time'>"+work.startTime+"-"+work.endTime+"</span>"+
							"<p class='mui-ellipsis clearfix' id='jobPath'>成果路径："+work.jobPath+"</p>"+
						"</div>"+
						"<div class='clear'></div>"+
						"<div class='line'></div>"+
						"<span id='proNo'>项目预算编号："+work.proNo+"</span></br>"+
						"<span id='proMile'>里程碑："+work.proMile+"</span></br>"+
						"<span id='jobName'>任务名称："+work.jobName+"</span></br>"+
						"<span id='jobRate'>任务完成进度："+work.jobRate+"%</span></br>"+
						"<span id='jobDisc'>任务描述："+work.jobDisc+"</span></br>"+	
						"<span>交付物：<a onclick='down("+url+","+i+")' id='fileName_"+i+"'>"+fileName+"</a></span>"+	
						"<input  type='hidden' value=''>"+	
					"</li>";
		$("#work").append(html);
	});
}
//生成报销信息
function initDailySpend(dailySpend){
	$.each(dailySpend,function(i,spend){
		var attachmentName='';
		if(spend.attachmentName){
			attachmentName = spend.attachmentName;
		}
		html="<div >"+
				"<li class='mui-table-view-cell'>"+
					"<span id='proNoS'>项目编号："+spend.proNo+"</span></br>"+
					"<span id='proNoS'>预算编号："+spend.deptId+"</span></br>"+
					"<span id='allotUser'>报销单号："+spend.spendNo+"单</span></br>"+
					"<span id='budgetType'>花消分类："+spend.budgetType+"</span></br>"+
					"<span id='spendType'>消费类型："+spend.spendType+"</span></br>"+
					"<span id='spendDateStr'>划卡日期："+spend.spendDateStr+"</span></br>"+
					"<span id=''>花销统计：</span></br>"+
					"<span>附件：<a onclick='downAttachment("+spend.attachmentId+","+i+")' id='attachmentName_"+i+"'>"+attachmentName+"</a></span>"+	
				"</li>"+
			"</div>";
		$("#assort").append(html);
	});
}
//生成发票信息
function initDailyAssort(dailyAssort){
	$.each(dailyAssort,function(i,assort){
		if(assort.rideType==null ||assort.rideType==""){
			assort.rideType="";
		}
		html="<li class='mui-table-view-cell'>"+
				"<div>"+
					"<div class='left' id='ticketType'>报销单号："+assort.spendNo+"单</div></br>"+
					"<div class='left' id='ticketType'>发票类型："+assort.ticketType+"</div></br>"+
					"<span class=left' id='spendMoney'>花销金额："+assort.spendMoney+"</span></br>"+
					"<div class='left' id='code'>报销单号："+assort.code+"</div></br>"+
					"<div class='left' id='rate'>税率&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;："+assort.rate+"%</div></br>"+
					"<div class='left' id='ticketCom'>开盘单位："+assort.ticketCom+"</div></br>"+
					"<div class='left' id='ticketInfo'>发票内容："+assort.ticketInfo+"</div></br>"+
					"<div class='left' id='remark'>备注&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;："+assort.remark+"</div></br>"+	
					"<div class='left' id='rideType'>乘车原因/时间："+assort.rideType+"</div></br>"+
					"<div class='left' id='teamSite'>团建时间/地点："+assort.teamSite+"</div></br>"+
					"<div class='left' id='teamUser'>团建人员："+assort.teamUser+"</div></br>"+
				"</div>"+
			"</li>";
		$("#assort").append(html);
	});
}
//生成明日计划
function initDailyPlan(dailyPlan){
	$.each(dailyPlan,function(i,plan){
		html="<div >"+
				"<li class=' mui-media relative mui-table-view-cell'>"+
					"<span class=''>"+plan.plan+"</span>"+
				"</li>"+
			"</div>";
		$("#plan").append(html);
	});
}
//提交
function checkDaily(){
	var ifAgree=$("#ifAgree").find(".mui-btn-primary").html();
	var dailyCheck=$("#dailyCheck").val();
	var evaluate=$("#showNo").html();
	$.ajax({
		url: pathUrl +'/auditDaily.action',
		type:'post',
		data:{
			pid:dailyId,
			ifAgree:ifAgree,
			dailyCheck:dailyCheck,
			taskId:taskId,
			taskUser:taskUser,
			evaluate:evaluate,
			userName:appUserInfo.mUserName
		},
		async:false,/*同步请求*/
		dataType:'jsonp',
		jsonp:'callback',
		jsonpCallback:'flightHandler',
		success:function(data){
		    var jsonData = JSON.parse(data);
			if(jsonData.code && 'SUCCESS' == jsonData.code){
				mui.confirm('审批成功！', '提示', ['确定'], function(e) {
					mui.openWindow({
						url:"agencyList.html"
					});
				});	
			}else{
				mui.confirm(jsonData.message, '提示', ['确定'], function(e) {
					mui.openWindow({
						url:"agencyList.html"
					});
				});
			}
		}
	});
}
function daka(list){
	//当地点为空时，字段不存在，做判断
	var site1 = '';
	var site2 = '';
	var site3 = '';
	var site4 = '';
	if(list.site1){
		site1 = list.site1;
	}
	if(list.site2){
		site2 = list.site2;
	}
	if(list.site3){
		site3 = list.site3;
	}
	if(list.site4){
		site4 = list.site4;
	}
	var html='<div class="mui-media detailMsg fadeBox">'+
		'<span class="mui-col-xs-6 ">上午上班&nbsp;'+ list.amAttendStr + '</span>' +
		'<span class="mui-col-xs-6 right">状态&nbsp;：'+ list.describe1 + '</span></br>' +
		'<span class="mui-col-xs-6 ">地点&nbsp;：'+ site1+ '</span></br>' +
		'<span class="mui-col-xs-6 ">上午下班&nbsp;'+ list.amClosingStr + '</span>' +
		'<span class="mui-col-xs-6 right">状态&nbsp;：'+ list.describe2 + '</span></br>' +
		'<span class="mui-col-xs-6 ">地点&nbsp;：'+ site2 + '</span></br>' +
		'<span class="mui-col-xs-6 ">下午上班&nbsp;'+ list.pmAttendStr + '</span>' +
		'<span class="mui-col-xs-6 right">状态&nbsp;：'+ list.describe3 + '</span></br>' +
		'<span class="mui-col-xs-6 ">地点&nbsp;：'+ site3 + '</span></br>' +
		'<span class="mui-col-xs-6 ">下午下班&nbsp;'+ list.pmClosingStr + '</span>' +
		'<span class="mui-col-xs-6 right">状态&nbsp;：'+ list.describe4 + '</span></br>' +
		'<span class="mui-col-xs-6 ">地点&nbsp;：'+ site4 + '</span></br>' +
		'</div>';
	$(".dakas").append(html);
}
function initUser(name){
	$("#taskUser").text(name);
	$("#taskDate").text(getLocalTime());
	
}
//获取当前时间
function getLocalTime() {  
	var date = new Date();
	var year = date.getFullYear();
	var month = date.getMonth() + 1;
	var day = date.getDate();
	var nowDate = year + "-" + month + "-" + day; 
	return nowDate;
}
//文件下载
function down(id,i){
	var fileName=$("#fileName_"+i).text();
	window.open(pathUrl+"/taskFile.action?id="+id+"&fileName="+fileName+"&flag=1"); 
}
//费用报销文件下载
function downAttachment(id,i){
	var attachmentName=$("#attachmentName_"+i).text();
	window.open(pathUrl+"/taskFile.action?id="+id+"&fileName="+attachmentName+"&flag=1"); 
}
