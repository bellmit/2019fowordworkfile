var procInsId;
var taskId;
var taskUser;
var id;
var appUserInfo = {};
var userId;
var cgId;
var procInstId;
var fileIds=null;
//页面初始化-初始化微信用户信息
$(function() {
    if(localStorage.wxUser!=null){
		var data = JSON.parse(localStorage.wxUser);
		appUserInfo.mUserName=data.userName;
		userId = data.userId;//用户id
	}else{
		mui.toast('网络异常！');
	}
    var data = JSON.parse(localStorage.obj);
	procInstId = data.procInstId;
	taskId = data.taskId;//审批id
	taskUser = data.taskUser;
	initView();
	document.getElementById('cgSku').addEventListener('tap', function() {
		var parameter=[];
		//获取当前时间戳
		var date = new Date().getTime();
		var obj = {procInstId:procInstId,cgId:cgId,date:date};
	    var parameter = JSON.stringify(obj);
	    localStorage.parameter = parameter;
		mui.openWindow({
			//跳转到费用类采购单
			url:'capitalOrder.html',
		})
	});
})(mui);

//生成费用类资金直接支付申请详细信息
function initView() {
	$.ajax({
		url:pathUrl+'/capitalPaymentView.action',
		type:"post",
		data:{
			procInstId:procInstId,
			taskId:userId,
			taskUser:taskUser
		},
		async:false,/*同步请求*/
		dataType:'json',	
		success:function(data){
			var json = JSON.parse(data);
			$("#sku").val(json.result.sku);
			$("#title").val(json.result.title);
			$("#payMethodName").val(json.result.payMethodName);
			$("#cdSku").val(json.result.cdSku);
			$("#askDate").val(json.result.askDate);
			$("#askName").val(json.result.askName);
			$("#askAmount").val(json.result.askAmount);
			$("#cgSku").text(json.result.cgSku);
			$("#yt").val(json.result.yt);
			$("#supplierName").val(json.result.supplierName);
			$("#payName").val(json.result.payName);
			$("#payAccount").val(json.result.payAccount);
			$("#explainFp").val('发票校验号：'+json.result.explainFp);
			$("#jpDate").val(json.result.jpDate);
			$("#rkInfo").val(json.result.rkInfo);
			$("#wantDate").val(json.result.wantDate);
			$("#askReason").val(json.result.askReason);
			var resu = json.result;
			fileIds=resu;
			//合同及相关附件
			if(resu.hasOwnProperty("htFileName")){
				$("#htFileName").text(resu.htFileName);
			}
			//验收报告
			if(resu.hasOwnProperty("ysbgFileName")){
				$("#ysbgFileName").text(resu.ysbgFileName);
			}
			//SVN配置库地址
			if(resu.hasOwnProperty("svnFileName")){
				$("#svnFileName").text(resu.svnFileName);
			}
			id=json.result.id;
			//获取费用采购单的参数
			cgId=json.result.cgId;
			procInstId=json.result.processInstanceId;
			recordList(json.old);
			$('input[type="text"]').attr('disabled','disabled');
		}
	});
}

//提交审批
function submits(){
	var a=document.getElementById('explainFp').value;
	var check=$("input[name='check']:checked").val();  
	var opinion=$("#opinion").val();
	var btnArray = ['确定'];
	if(!check){
		mui.confirm('请选择审批结果', '', ['确定'], function(e) {
		});
		return false;
	}
	if(!opinion){
		mui.confirm('审批意见不可为空', '', ['确定'], function(e) {
		});
		return false;
	}
	$("#btns").attr("disabled","disabled");
	$.ajax({
		url:pathUrl+'/checkCapitalPayment.action',
		type:"post",
		data:{
			userId:userId,
			taskUser:taskUser,
			id:id,
			opinion:opinion,
			isAgree:check
		},
		async:false,/*同步请求*/
		dataType:'json',
		success:function(data){
			var json = JSON.parse(data);
			if(json && json.hasOwnProperty("result") && json.result==true){
				mui.confirm('审批成功', '提示', ['确定'], function(e) {
					mui.openWindow({
						url:"agencyList.html"
					});	
				});
			}else{
				mui.confirm('审批失败', '提示', ['确定'], function(e) {
					mui.openWindow({
						url:"agencyList.html"
					});	
				});	
			}
		}
	});	
}
//审批记录列表
function recordList(json){
	var dataList = JSON.parse(json);
	var html='';
	if(dataList.hasOwnProperty("list") && dataList.list.length > 0){
		$.each(dataList.list,function(i,list){
			var attitude="";
			if(list.attitude=="1"){
				attitude="同意";
			}else{
				attitude="不同意";
			}
			if(list.taskUser == list.taskFinishUser){
				html = '<li class="clearfix "><span class="left label">审批人：</span> '+
							'<input type="text" id="" class="f_input right wp60" value="'+list.taskUser+'">'+
						'</li>';
			}else {
				html = '<li class="clearfix "><span class="left label">审批人：</span> '+
							'<span type="text" id="" class="f_input mui-pull-right" style="padding-right:10px">'+list.taskUser+'(代理人：'+list.taskFinishUser+')'+'</span>'+
						'</li>';
			}
			html = html+'<li class="clearfix "><span class="left label">审批结果：</span> '+
							'<input type="text" id="" class="f_input right wp60" value="'+attitude+'">'+
						'</li>'+
						'<li class="clearfix "><span class="left label">审批意见：</span> '+
							'<input type="text" id="" class="f_input right wp60" value="'+list.message+'">'+
						'</li>'+
						'<li class="clearfix "><span class="left label">审批时间：</span> '+
							'<span type="text" id="" class="f_input mui-pull-right" style="padding-right:10px">'+list.taskFinishTime+'</span>'+
						'</li></br>';
			$("#apply").append(html);
		});
	}

}
function fileDown(fileId){
	var id=0;
	var fileName=null;
	if(fileId=="htFile"){
	
		fileName=$("#htFileName").text();
		id=fileIds.htFile;
	}else if(fileId=="ysbgFile"){
		
		fileName=$("#ysbgFileName").text();
		id=fileIds.ysbgFile;
	}else if(fileId=="svnFile"){
	
		fileName=$("#svnFileName").text();
		id=fileIds.svnFile;
	}
	window.open("https://www.wanglin.online:8888/RunErpSystem/taskFile.action?id="+id+"&fileName="+fileName); 
}