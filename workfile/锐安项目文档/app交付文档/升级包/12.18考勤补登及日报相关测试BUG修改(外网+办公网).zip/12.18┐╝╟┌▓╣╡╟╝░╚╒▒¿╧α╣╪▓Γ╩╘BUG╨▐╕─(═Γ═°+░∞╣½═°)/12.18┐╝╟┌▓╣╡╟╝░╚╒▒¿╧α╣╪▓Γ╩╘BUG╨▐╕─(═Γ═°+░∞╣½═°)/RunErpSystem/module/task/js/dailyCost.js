var procInsId;
var taskId;
var taskUser;
var id;
var appUserInfo = {};
//页面初始化-初始化微信用户信息
(function($) {
    $.init();
    if(localStorage.wxUser!=null){
		var data = JSON.parse(localStorage.wxUser);
		appUserInfo.mUserName=data.userName;
		appUserInfo.mUserId = data.userId;
	}else{
		mui.toast('网络异常！');
	}
    var data = JSON.parse(localStorage.obj);
	procInstId = data.procInstId;
	taskId = data.taskId;
	taskUser = data.taskUser;
	initView();
})(mui);
//生成日报审批的详细数据
function initView() {
	$.ajax({
		url:pathUrl+'/dailyCost.action',
		type:"post",
		data:{
			procInstId:procInstId,
			taskId:taskId,
			taskUser:taskUser,
			userName:appUserInfo.mUserName
		},
		async:false,/*同步请求*/
		dataType:'json',
		success:function(data){
			var jsonData = JSON.parse(data);
			//日报基本信息
			if (jsonData.dailyInfo) {
			    dailyId = jsonData.dailyInfo.id;
			}
			$('#dailyDate').html(jsonData.dailyInfo.dailyDateStr+"日报");
			$('#applyUser').html(jsonData.dailyInfo.applyUser);
			$('#workHour').html(jsonData.dailyInfo.workHour);
			$('#subState').html(jsonData.dailyInfo.subState);
			$('#submitDate').html(jsonData.dailyInfo.submitDateStr+"提交");
			$('#site').html(jsonData.dailyInfo.site);
			$('#evaluate').html(jsonData.dailyInfo.evaluate);
			$('#evaluateDisc').html(jsonData.dailyInfo.evaluateDisc);
			$('#checkDesc').val(jsonData.dailyInfo.checkDesc);
			$('#showNo').html(jsonData.dailyInfo.evaluate);
			$('#checkDate').html(jsonData.dailyInfo.checkDate);
			//报工内容
			initDailyWork(jsonData.workList);
			//报销
			initDailySpend(jsonData.dailySpend);
			//发票
			initDailyAssort(jsonData.dailyAssort);
			daka(jsonData.attendInfo);
			$.each(jsonData.logList,function(i,flow){
				if(flow.isAgree==1){
					flow.isAgree="同意";
				}else{
					flow.isAgree="不同意";
				}
	    	    var html="<div class='mui-card-content-inner'>"+
			                 "<span class='mui-pull-left'>审批人</span>"+
			                 "<span class=' mui-pull-right'>"+flow.taskUser+"</span>"+
			             "</div>"+
			             "<div class='mui-card-content-inner'>"+
			                 "<span class='mui-pull-left'>审批结果</span>"+
			                 "<span class=' mui-pull-right'>"+flow.isAgree+"</span>"+
			             "</div>"+
			             "<div class='mui-card-content-inner'>"+
				             "<span class='mui-pull-left'>审批时间</span>"+
				             "<span class=' mui-pull-right'>"+getLocalTime(flow.taskFinishTime)+"</span>"+
			             "</div>"+
			             "<div class='mui-card-content-inner'>"+
				             "<span>审批意见</span>"+
				             "<span class=' mui-pull-right'>"+flow.examineOption+"</span>"+
			             "</div>"
			     $("#auditHis").append(html);
		     });
		}
	});
}
//生成报工内容
function initDailyWork(workList){
	$.each(workList,function(i,work){
	if(!work.workHour){
		work.workHour=0;
	}
		html="<li class=' mui-media relative mui-table-view-cell'>"+
						"<div class='myui-circle-list-icon mui-pull-left'><span id='workHourSon'>"+work.workHour+" <em>h</em></span></div>"+
						"<div class='mui-media-body mui-pull-left'>"+
							"用时<span class='l10 blue' id='time'>"+work.startTime+"-"+work.endTime+"</span>"+
							"<p class='mui-ellipsis clearfix' id='jobPath'>成果路径："+work.jobPath+"</p>"+
						"</div>"+
						"<div class='clear'></div>"+
						"<div class='line'></div>"+
						"<span class=' left' id='proNo'>项目预算编号："+work.proNo+"</span></br>"+
						"<span class=' left' id='proNo'>任务完成进度："+work.jobRate+"%</span></br>"+
						"<span class=' left' id='proMile'>里程碑："+work.proMile+"</span></br>"+
						"<span class=' left' id='jobName'>任务名称："+work.jobName+"</span></br>"+
						"<span  id='jobDisc'>任务描述："+work.jobDisc+"</span>"+	
					"</li>";
		$("#work").append(html);
	});
}
//生成报销信息
function initDailySpend(dailySpend){

	$.each(dailySpend,function(i,spend){
		html="<div >"+
				"<li class='mui-table-view-cell'>"+
					"<span class='left ' id='proNoS'>项目编号："+spend.proNo+"</span></br>"+
					"<span class='left ' id='proNoS'>预算编号："+spend.deptId+"</span></br>"+
					"<span class='left ' id='allotUser'>报销单号："+spend.spendNo+"单</span></br>"+
					"<span class='left '>花消分类："+spend.budgetType+"</span></br>"+
					"<span class='left ' id='spendType'>消费类型："+spend.spendType+"</span></br>"+
					"<span class='left ' id='spendDateStr'>划卡日期："+spend.spendDateStr+"</span></br>"+
					"<span class='left ' id=''>花销统计：</span>"+
				"</li>"+
			"</div>";
		$("#assort").append(html);
	});
}
//生成发票信息
function initDailyAssort(dailyAssort){
	$.each(dailyAssort,function(i,assort){
		html="<li class='mui-table-view-cell'>"+
				"<div>"+
					"<div class='left' id='ticketType'>报销单号："+assort.spendNo+"单</div></br>"+
					"<div class='left' id='ticketType'>发票类型："+assort.ticketType+"</div></br>"+
					"<span class=left' id='spendMoney'>花销金额："+assort.spendMoney+"</span></br>"+
					"<div class='left' id='code'>报销单号："+assort.code+"</div></br>"+
					"<div class='left' id='rate'>税率&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;："+assort.rate+"%</div></br>"+
					"<div class='left' id='ticketCom'>开盘单位："+assort.ticketCom+"</div></br>"+
					"<div class='left' id='ticketInfo'>发票内容："+assort.ticketInfo+"</div></br>"+
					"<div class='left' id='remark'>备注&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;："+assort.remark+"</div></br>"+	
					"<div class='left' id='rideType'>乘车原因/时间："+assort.rideType+"</div></br>"+
					"<div class='left' id='teamSite'>团建时间/地点："+assort.teamSite+"</div></br>"+
					"<div class='left' id='teamUser'>团建人员："+assort.teamUser+"</div></br>"+
				"</div>"+
			"</li>";
		$("#assort").append(html);
	});
}
//审批提交
function checkDaily(){
	var ifAgree=$("#ifAgree").find(".mui-btn-primary").html();
	var comment=$("#dailyCheck").val();
	var btnArray = ['确定'];
	$.ajax({
		url: pathUrl +'/CheckDailySpend.action',
		type:'post',
		data:{
			procInstId:procInstId,
			ifAgree:ifAgree,
			taskId:taskId,
			taskUser:taskUser,
			comment:comment
		},
		async:false,/*同步请求*/
		dataType:'jsonp',
		jsonp:'callback',
		jsonpCallback:'flightHandler',
		success:function(data){
		    var jsonData = JSON.parse(data);
			if(jsonData.result && 'success' == jsonData.result){
				mui.confirm('审批成功！', '提示', btnArray, function(e) {
					mui.openWindow({
						url:"agencyList.html"
					});
				});	
			}else{
				mui.confirm(jsonData.message, '提示', btnArray, function(e) {
					mui.openWindow({
						url:"agencyList.html"
					});
				});
			}
		}
	});
}
function daka(list){
	var html='<div class="mui-media detailMsg fadeBox">'+
		'<span class="mui-col-xs-6 ">上午上班&nbsp;'+ list.amAttendStr + '</span>' +
		'<span class="mui-col-xs-6 right">状态&nbsp;：'+ list.describe1 + '</span></br>' +
		'<span class="mui-col-xs-6 ">地点&nbsp;：'+ list.site1+ '</span></br>' +
		'<span class="mui-col-xs-6 ">上午下班&nbsp;'+ list.amClosingStr + '</span>' +
		'<span class="mui-col-xs-6 right">状态&nbsp;：'+ list.describe2 + '</span></br>' +
		'<span class="mui-col-xs-6 ">地点&nbsp;：'+ list.site2 + '</span></br>' +
		'<span class="mui-col-xs-6 ">下午上班&nbsp;'+ list.pmAttendStr + '</span>' +
		'<span class="mui-col-xs-6 right">状态&nbsp;：'+ list.describe3 + '</span></br>' +
		'<span class="mui-col-xs-6 ">地点&nbsp;：'+ list.site3 + '</span></br>' +
		'<span class="mui-col-xs-6 ">下午下班&nbsp;'+ list.pmClosingStr + '</span>' +
		'<span class="mui-col-xs-6 right">状态&nbsp;：'+ list.describe4 + '</span></br>' +
		'<span class="mui-col-xs-6 ">地点&nbsp;：'+ list.site4 + '</span></br>' +
		'</div>';
	$(".dakas").append(html);
}
function getLocalTime(nS) {     
   return new Date(parseInt(nS)).toLocaleString().replace(/:\d{1,2}$/,' ');     
}