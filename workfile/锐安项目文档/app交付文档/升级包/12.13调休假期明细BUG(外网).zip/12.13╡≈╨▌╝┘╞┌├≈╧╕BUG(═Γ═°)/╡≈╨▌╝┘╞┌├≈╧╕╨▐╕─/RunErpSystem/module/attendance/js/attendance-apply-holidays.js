var userId="";
mui.init({
swipeBack:true //启用右滑关闭功能
});

//初始化微信用户
(function($) {
   $.init();
   setTimeout(function () {
	  if(localStorage.wxUser!=null){
		var data = JSON.parse(localStorage.wxUser);
		userId=data.userId;
		if (userId &&　userId != null && userId != "" && userId != "undefined") {
		    initView();
		} else {
		    mui.toast('Failed to get user inforamtion！');
		}
		//initView();
	  }else{
		mui.toast('网络异常！');
	  }	
	}, 800);
})(mui);
var testUrl = pathUrl+'/getholidays.action';
//查看详情
function initView(leavelId) {
	$.ajax({
		url: pathUrl+'/getholidays.action',
		type:"post",
		data:{userId:userId},
		async:false,/*同步请求*/
		error : function(jqXHR, textStatus, errorThrown){
		    if (userId && userId == 2530) {
		        alert(jqXHR.responseText);
			    alert(textStatus);
			    alert(errorThrown);
		    } else {
		        alert(userId);	        
		    }
		    alert(testUrl);
		    alert("获假期明细失败，请联系管理员！");
		},
		success:function(data){
			var jsonData = JSON.parse(data);
			var index = 0;
		  	$.each(jsonData.data,function(i,flow){
		  	            index++;
		  				var html='<li class="mui-table-view-cell mui-media detailMsg fadeBox">'+
							'<div>'+
								'当前登陆人： <span id="reason">'+flow.userName+'</span>'+
							'</div>'+
							'<div>'+
								'总小时数：<span id="replaceUserName">'+flow.totalHours+'</span>'+
							'</div>'+
							'<div>'+
								'剩余小时数：<span id="replaceUserName">'+flow.restHours+'</span>'+
							'</div>'+
							'<div>'+
								'假期类型：<span id="replaceUserName">'+flow.holidayType+'</span>'+
							'</div>'+
							'<div>'+
								'有效期：<span id="replaceUserName">'+flow.startValidity+'-'+flow.endValidity+'</span>'+
							'</div>'+
						'</li>';
			    	$("#datas").append(html);
			 });
			 if (index == 0) {
			    $("#datas").append("no record found"); 
			 }
		}
	});
}
