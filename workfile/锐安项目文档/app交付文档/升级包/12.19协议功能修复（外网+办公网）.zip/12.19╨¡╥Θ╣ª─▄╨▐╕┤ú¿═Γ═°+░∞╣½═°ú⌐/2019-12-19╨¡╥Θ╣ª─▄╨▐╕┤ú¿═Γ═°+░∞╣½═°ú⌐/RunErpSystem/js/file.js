var delfile = [];
var timer=null;
var fileName;
var files;
mui.ready(function() {
	//添加文件
	$('.fileAdd').off().on('click',function(){
	    var inputName = new Date().getTime();
	    var _html = '<input type="file" class="hide fileInput" data-id="'+inputName+'" multiple/>';
	    $('.fileBox').after(_html);
	
	    $('input[data-id="'+inputName+'"]').click();
	});

	//文件选择变化
	$('.fileInput').die().live('change',function(e) {
		var _html = '';
		var filelength = e.target.files.length;
		if((filelength+$('.fileBox .imgbtn').length)>1){
			mui.confirm('不能同时上传多个文件', '', ['确定'], function(e) {
			});
			return false;
		}
		if(e.target.files.length<=1){
			var file = e.target.files[0];
			var strFile = file.name;
	   		fileName = file.name;
	   		$("#fileName").text(fileName);
			if(strFile.indexOf(";")!=-1){
				mui.confirm('文件名称不能带 ; ', '', ['确定'], function(e) {
				});
				return false;
			}
			//上传控制！！！！！！！！
			const imgMaxSize = 1024 * 1024 * 5 ; // 5MB
			// 检查文件类型
	
			// 文件大小限制
			if(file.size > imgMaxSize ) {
				showAlert("文件大小不能超过5MB！");
				return false;
			}	
			if(file.name!=null&&file.name!='/'){
				goToFileUp(file);
				_html='<span class="imgbtn left relative" data-input="'+$(e.target).attr("data-id")+'" data-time="'+file.lastModified+'">'+
			         '<img src="../../images/imgicon.png" class="imgicon" />'+
			         '<a href="javascript:;" class="imgdelbtn">'+
			         '<img src="../../images/delicon.png" alt class="imgdelicon" />'+					
			         '</a>'+
			         '</span>';
			}
	
		}else{
			var x = 100;
			var y = 0;
	   		var rand = parseInt(Math.random() * (x - y + 1) + y);
			var file = e.target.files;
			$.each(file,function(i,item){
				var strFile=item.name;
				if(strFile.indexOf(";")!=-1){
					mui.confirm('文件名称不能带 ; ', '', ['确定'], function(e) {
					});
					return false;
				}
				//上传控制！！！！！！！！
				const imgMaxSize = 1024 * 1024 * 5; // 5MB
				// 检查文件类型
	
				// 文件大小限制
				if(file.size > imgMaxSize ) {
					showAlert("文件大小不能超过5MB！");
					return false;
				}	
				if(file.name!=null&&file.name!='/'){
					goToFileUp(file);
	                _html+='<span class="imgbtn left relative" data-input="'+$(e.target).attr("data-id")+'" data-time="'+item.lastModified+'">'+
	                    '<img src="../../images/imgicon.png" class="imgicon"/>'+
	                    '<a href="javascript:;" class="imgdelbtn">'+
	                    '<img src="../../images/delicon.png" alt class="imgdelicon" />'+
	                    '</a>'+
	                    '</span>';
				}
			});
		}
		$('.fileBox').append(_html);
	    
	});
	//关闭文件
	$('.imgdelbtn').die().live('touchend',function(){
		var fileId = $(this).parent().attr('data-time'); //file中的lastModified
		delfile.push(fileId);
		$(this).parent().remove();
		$("#fileName").text("");
		return false;
	});
});
function goToFileUp(file){
			
	// 图片上传							
	//transformFileToFormData(file);	
	// 图片压缩绘制
	// transformFileToDataUrl(file);
	// 图片上传
	transformFileToFormData(file);
}
// 将File append进 FormData
function transformFileToFormData (file) {
	localStorage.files=file.size;
    const formData = new FormData();
    // name
    formData.append('name', file.name);
    // append 文件
    formData.append('businessFile', file);	
    // 上传图片
    uploadMobileFile(formData);
}
function uploadMobileFile(formData){
	var sku=$("#sku").val();
	$.ajax({
		url: pathUrl+'/attFileMobile.action?sku='+sku+"&flag=xy",
		type:"post",
		data:formData,
		async:false,/*同步请求*/
		dataType:"json",
		contentType:false,
		processData:false,
		error : function(){
			$("#fileName").text("");
			mui.toast("上传图片失败！");
		},
		success:function(data){
			var data=JSON.parse(data);
			if(data.attachmentId!="" || data.attachmentId!=null){
				localStorage.dzfjFile=data.attachmentId;
				$("#fileName").text(fileName);
				mui.confirm(data.result, '', ['确定'], function(e) {
				});
			}else{
				$("#fileName").text("");
				mui.confirm('图片太大了！', '', ['确定'], function(e) {
				});
			}				
			
		}
	});
}
//协议文件下载
function fileDown(fileId){
	var id=0;
	var fileName=null;
	if(fileId=="xyFile"){
		fileName=$("#xyFile").text();
		id=fileIds.xyFile.id;
	}else if(fileId=="gysghnlFile"){
		fileName=$("#gysghnlFile").text();
		id=fileIds.gysghnlFile.id;
	}else if(fileId=="companyFile"){
		fileName=$("#companyFile").text();
		id=fileIds.companyFile.id;
	}else if(fileId=="personFile"){
		fileName=$("#personFile").text();
		id=fileIds.personFile.id;
	}else if(fileId=="zbFile"){
		fileName=$("#zbFile").text();
		id=fileIds.zbFile.id;
	}else if(fileId=="cpxxFile"){
		fileName=$("#cpxxFile").text();
		id=fileIds.cpxxFile.id;
	}else if(fileId=="cpdlsFile"){
		fileName=$("#cpdlsFile").text();
		id=fileIds.cpdlsFile.id;
	}else if(fileId=="otherFile"){
		fileName=$("#otherFile").text();
		id=fileIds.otherFile.id;
	}else if(fileId=="dzfjFile"){
		fileName=$("#dzfjFile").text();
		id=fileIds.dzfjFile.id;
	}else if(fileId=="cancelFile"){
		fileName=$("#cancelFile").text();
		id=fileIds.cancelFile.id;
	}
	window.open("https://www.wanglin.online:8888/RunErpSystem/taskFile.action?id="+id+"&fileName="+fileName); 
}