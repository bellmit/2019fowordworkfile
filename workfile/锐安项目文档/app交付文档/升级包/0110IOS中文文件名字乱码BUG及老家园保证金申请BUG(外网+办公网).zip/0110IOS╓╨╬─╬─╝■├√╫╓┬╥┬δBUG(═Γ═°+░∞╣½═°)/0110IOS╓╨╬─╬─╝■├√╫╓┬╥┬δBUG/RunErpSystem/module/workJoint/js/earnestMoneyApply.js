var appUserInfo = {};
var userId;
var procInstId;
var nodeLevel; //节点id
var marginId; //申请单id 
//页面初始化-初始化微信用户信息
$(function() {
    if(localStorage.wxUser!=null){
		var data = JSON.parse(localStorage.wxUser);
		appUserInfo.mUserName=data.userName;
		userId = data.userId;
	}else{
		mui.toast('网络异常！');
	}
    var data = JSON.parse(localStorage.obj);
	procInstId = data.procInstId;
	initView();
	//时间选择
    var btns = $('.btns');
	btns.each(function(i, btn) {
		btn.addEventListener('tap', function() {
			var optionsJson = this.getAttribute('data-options') || '{}';
			var options = JSON.parse(optionsJson);
			var id = this.getAttribute('id');
			var picker = new mui.DtPicker(options);
			picker.show(function(rs) {
				btn.innerText = rs.text;
				picker.dispose();
				picker = null;
			});
		}, false);
	});
	//选择未中标时，显示对方合同签订日期选择
	$("input:radio[name='tender']").change(function(){
    	var tender = $("input[name='tender']:checked").val();
		if(tender == '1'){
			if(!$("#other").hasClass("display_none")){
				$("#other").addClass("display_none");
			}
		} else {
			if($("#other").hasClass("display_none")){
				$("#other").removeClass("display_none");
			}
		}
	});
})(mui);

//查看保证金申请审批详情 33479
function initView() {
	$.ajax({
		url:pathUrl+'/earnestMoneyApply.action',
		type:"post",
		data:{
			examineLogId:procInstId
		},
		async:false,/*同步请求*/
		dataType:'json',
		success:function(data){
			var json = JSON.parse(data);
			var applyDate=transform(json.marginInfo.applyDate);
			$("#applyDate").val(applyDate);
			$("#receiptsNo").val(json.marginInfo.receiptsNo);
			$("#applyUser").val(json.marginInfo.applyUser);
			$("#firstDept").val(json.marginInfo.firstDept);
			var isProject = judge(json.marginInfo.isProject);
			$("#isProject").val(isProject);
			$("#marginType").val(json.marginInfo.marginType);
			$("#proName").text(json.marginInfo.proName);
			$("#proNo").val(json.marginInfo.proNo);
			$("#dealChance").val(json.marginInfo.dealChance);
			$("#dealChanceNow").val(json.marginInfo.dealChanceNow);
			var yjqdTime=transform(json.marginInfo.yjqdTime);
			$("#yjqdTime").val(yjqdTime);
			$("#yjhte").val(json.marginInfo.yjhte);
			
			$("#conditionRemark").text(json.marginInfo.conditionRemark);
			$("#applyMoney").val(json.marginInfo.applyMoney);
			var predictDate = transform(json.marginInfo.predictDate);
			$("#predictDate").val(predictDate);
			$("#clientName").val(json.marginInfo.clientName);
			$("#collection").val(json.marginInfo.collection);
			$("#bankName").text(json.marginInfo.bankName);
			$("#bankNo").text(json.marginInfo.bankNo);
			$("#marginFile").text(json.marginInfo.marginFile);
			//预计付款日期
			var predictPayDate = transform(json.marginInfo.predictPayDate);
			$("#predictPayDate").val(predictPayDate);
			$("#reasion").text(json.marginInfo.reasion);
			$("#remarks").text(json.marginInfo.remarks);
			var shudPayDate = transform(json.marginInfo.shudPayDate);
			$("#shudPayDate").val(shudPayDate);
			var realPayDate = transform(json.marginInfo.realPayDate);
			$("#realPayDate").val(realPayDate);
			$("#pressUser").val(json.marginInfo.pressUser);
			$("#pressDept").val(json.marginInfo.pressDept);
			var htzxDate = transform(json.marginInfo.htzxDate);
			$("#htzxDate").val(htzxDate);
			var data = json.marginInfo;
			var dayType = getDayType(data.dayType);
			var qsbsType = getQsbsType(data.qsbsType);
			var dayOneType = getDayType(data.dayOneType);
			var qsbsOneType = getQsbsType(data.qsbsOneType);
			if(json.marginInfo.marginType == "投标保证金"){
				$("li[name='tenderMargin']").removeClass("display_none");
				var receivableYes = data.conditionType+" "+data.year+"年"+data.month+"月"+data.day+dayType+qsbsType;
				var receivableNo = data.conditionNOType+" "+data.yearOne+"年"+data.monthOne+"月"+data.dayOne+dayOneType+qsbsOneType;
				$("#receivableYes").text(receivableYes);
				$("#receivableNo").text(receivableNo);
				$("#zbClient").val(data.zbClient);
				$("#zbType").val(data.zbType);
				$("#moneySource").val(data.moneySource);
				var tbDate = transform(data.tbDate);
				$("#tbDate").val(tbDate);
			} else {
				$("li[name='qualityMargin']").removeClass("display_none");
				var receivable = data.conditionType+" "+data.year+"年"+data.month+"月"+data.day+dayType+qsbsType;
				$("#receivable").text(receivable);
			};
			responses(json);
			commentsList(json.examineLogList);
			marginId = data.id;
			nodeLevel = json.nodeLevel;
			$('input[type="text"]').attr('readOnly','readOnly');
		}
	});
}

//Timestamp转换Date格式（2019-01-01 12:00:00）
function transformDate(data){
	var times;
	if(data){
		var time = new Date(data);
    	var year = time.getFullYear();
    	var month = time.getMonth()+1;
    	var date = time.getDate();
		var hours = time.getHours();
    	var minutes = time.getMinutes();
    	var seconds = time.getSeconds();
    	times = year+'-'+addZero(month)+'-'+addZero(date)+' '+addZero(hours)+':'+addZero(minutes)+':'+addZero(seconds);
	}
	return times;
}

//Timestamp转换Date格式（2019-01-01）
function transform(data){
	var timeOne;
	if(data){
		var time = new Date(data);
    	var year = time.getFullYear();
    	var month = time.getMonth()+1;
    	var date = time.getDate();
    	timeOne = year+'-'+addZero(month)+'-'+addZero(date);
	}
	return timeOne;
}
function addZero(m){
	return m<10?'0'+m:m;
}
//1/0 转化为 '是'/'否'
function judge(data){
	var judge = (data == '1') ? '是' : '否';
	return judge;
}
//1/0 转化为 '内'/'后'
function getQsbsType(data){
	var qsbs = (data == '1') ? '内' : '后';
	return qsbs;
}
//1/2 转化为 '自然日'/'工作日'
function getDayType(data){
	var dayType = (data == '1') ? '自然日' : '工作日';
	return dayType;
}
//获取回复意见
function responses(data){
	var html;
	if(data.nodeLevel == '225'){
		html='<li class="clearfix"><span class="left label">审批结果：</span>'+
				'<span class="result right" style="padding-right:20px">'+
				'<input type="radio" name="check" value="1"/>同意'+
				'<input type="radio" name="check" value="2"/>不同意'+
				'</span>'+
			'</li>'+
			'<li class="clearfix" style="height: auto;"><span class="left label">审批意见：</span>'+
				'<textarea class="mui-input-speech t10 result" style="margin-bottom: 0;" id="examineOpinion" rows="5" placeholder="请输入审批意见"></textarea>'+
			'</li></br>';
	} else if(data.nodeLevel == '226'){
		html='<li class="clearfix "><span class="left label">付款日期：</span>'+
				'<input type="text" id="payDates" class="f_input right wp60">'+
			'</li>'+
			'<li class="clearfix "><span class="left label">付款金额(元)：</span> '+
				'<input type="text" id="payMoneys" class="f_input right wp60" value="'+sum+'">'+
			'</li>'+
			'<li class="clearfix "><span class="left label">收款方名称：</span> '+
				'<input type="text" id="payCollections" class="f_input right wp60" value="'+sum+'">'+
			'</li>'+
			'<li class="clearfix "><span class="left label">付款银行：</span> '+
				'<input type="text" id="payBankNames" class="f_input right wp60" value="'+sum+'">'+
			'</li>'+
			'<li class="clearfix "><span class="left label">备注：</span> '+
				'<textarea class="mui-input-speech t10 result" style="margin-bottom: 0;" id="payRemarks" rows="5" placeholder="请输入备注"></textarea>'+
			'</li></br>';
	} else if(data.nodeLevel == '4348'){
		html='<li class="clearfix "><span class="left label">投标结果：</span> '+
				'<span class="result right" style="padding-right:20px">'+
					'<input type="radio" name="tender" value="1"/>中标'+
					'<input type="radio" name="tender" value="2"/>未中标'+
				'</span>'+
			'</li>'+
			'<li class="clearfix display_none" id="other">'+
				'<div class="left label">对方合同签订日期</div>'+
				'<span id="demo1" data-options="{"type":"date","beginYear":2000,"endYear":2099}" class="btns right mr" style="padding-right:20px">结束时间</span>'+
			'</li>'+
			'<li class="clearfix" id="noBuru">'+
				'<div class="left label">发出中标通知书日期</div>'+
				'<span id="demo2" data-options="{"type":"date","beginYear":2000,"endYear":2099}" class="btns right mr" style="padding-right:20px">结束时间</span>'+
			'</li>'+
			'<li class="clearfix" id="noBuru">'+
				'<div class="left label">公示日期</div>'+
				'<span id="demo4" data-options="{"type":"date","beginYear":2000,"endYear":2099}" class="btns right mr" style="padding-right:20px">结束时间</span>'+
				'<img src="../../images/adr-arrow.png" class="right" alt="" style="height: 25px;margin: 8px 10px;">'+
				'<span id="demo3" data-options="{"type":"date","beginYear":2000,"endYear":2099}" class="btns right mr">开始时间</span>'+
			'</li>'+
			'<li class="clearfix"><span class="left label">中标通知书：</span>'+
				'<input type="text" id="responsiblePersonName" class="f_input right wp60">'+
			'</li>'+
			'<li class="clearfix" style="height: auto;"><span class="left label">备注：</span>'+
				'<textarea class="mui-input-speech t10 result" style="margin-bottom: 0;" id="examineOpinion" rows="5" placeholder="请输入审批意见"></textarea>'+
			'</li></br>';
	} else {
		html='<li class="clearfix"><span class="left label">审批结果：</span>'+
				'<span class="result right" style="padding-right:20px">'+
				'<input type="radio" name="check" value="1"/>同意'+
				'<input type="radio" name="check" value="2"/>不同意'+
				'</span>'+
			'</li>'+
			'<li class="clearfix" style="height: auto;"><span class="left label">审批意见：</span>'+
				'<textarea class="mui-input-speech t10 result" style="margin-bottom: 0;" id="examineOpinion" rows="5" placeholder="请输入审批意见"></textarea>'+
			'</li></br>';
	}
	$("#responses").append(html);
}
//生成历史审批记录
function commentsList(json){
	if(json.length > 0){
		$.each(json,function(i,list){
			var attitude="";
			var nodeMan;
			if(list.isAgree=="1"){
				attitude="同意";
			}else{
				attitude="不同意";
			}
			var dealTime = transformDate(list.dealTime);
			if(list.hasOwnProperty("agentUserName")){
				nodeMan = list.nodeMan+"(代理:"+list.agentUserName+")";
			} else {
				nodeMan = list.nodeMan;
			}
			var html='<li class="clearfix "><span class="left label">节点名称：</span> '+
						'<input type="text" id="" class="f_input right wp60" value="'+list.nodeName+'">'+
					'</li>'+
					'<li class="clearfix "><span class="left label">是否同意：</span> '+
						'<input type="text" id="" class="f_input right wp60" value="'+attitude+'">'+
					'</li>'+
					'<li class="clearfix "><span class="left label">审批人：</span> '+
						'<span type="text" id="" class="f_input mui-pull-right" style="padding-right:20px">'+nodeMan+'</span>'+
					'</li>'+
					'<li class="clearfix "><span class="left label">审批时间：</span> '+
						'<span type="text" id="" class="f_input mui-pull-right" style="padding-right:20px">'+dealTime+'</span>'+
					'</li>'+
					'<li class="clearfix "><span class="left label">审批意见：</span> '+
						'<input type="text" id="" class="f_input right wp60" value="'+list.spOption+'">'+
					'</li></br>';
			$("#commentsList").append(html);
		})
	}
}

//提交审批
function submits(){
	var check=$("input[name='check']:checked").val();
	var opinion=$("#examineOpinion").val();
	
	if(!check){
		mui.confirm('请选择审批结果', '', ['确定'], function(e) {
		});
		return false;
	}
	if(!opinion){
		mui.confirm('请填写审批意见', '', ['确定'], function(e) {
		});
		return false;
	}
	$("input[name='check']").attr("disabled","disabled");
	$("#opinion").attr("disabled","disabled");
	$("#btns").attr("disabled","disabled");
	$.ajax({
		url:pathUrl+'/checkMarginYszk.action',
		type:"post",
		data:{
			state:check,
			examineOpinion:opinion,
			marginId:marginId,
			examineId:procInstId,
			nodeLevel:nodeLevel,
			name:appUserInfo.mUserName
		},
		dataType:'json',
		success:function(data){
			var json = JSON.parse(data);
			if(json.result=="审批成功！"){
				mui.confirm(json.result, '提示', ['确定'], function(e) {
					mui.openWindow({
						url:"agencyList.html"
					});	
				});	
			}else{
				mui.confirm(json.result, '提示', ['确定'], function(e) {
					mui.openWindow({
						url:"agencyList.html"
					});	
				});	
			}
		}
	});
}
function down(a){
	var fileName=$("#"+a).text();
	var path="margin/"+fileName;
	window.open(pathUrl+"taskFile.action?filePath="+path+"&fileName="+fileName+"&flag=4"); 
}